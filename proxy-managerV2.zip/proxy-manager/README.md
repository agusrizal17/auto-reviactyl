# Proxy Manager

By Misty Development.

Map public domains to backend `host:port` targets and automatically deploy
Nginx reverse-proxy configurations with optional SSL via Certbot.

## Requirements

- Reviactyl
- Nginx
- Certbot
- A server where the Reviactyl panel can safely manage the required Nginx
  configuration
- Appropriate sudo permissions for the panel's `www-data` user

## Sudoers setup

The panel runs as `www-data`. Create:

`/etc/sudoers.d/proxy-manager`

with:

```text
www-data ALL=(root) NOPASSWD: /usr/sbin/nginx -t
www-data ALL=(root) NOPASSWD: /bin/systemctl reload nginx
www-data ALL=(root) NOPASSWD: /usr/bin/certbot --nginx -d *
www-data ALL=(root) NOPASSWD: /bin/ln -sf /etc/nginx/sites-available/* /etc/nginx/sites-enabled/*
www-data ALL=(root) NOPASSWD: /bin/cp /var/www/pterodactyl/extensions/proxy-manager/data/generated/*.conf /etc/nginx/sites-available/*.conf
www-data ALL=(root) NOPASSWD: /bin/rm /etc/nginx/sites-enabled/*.conf
```

> Adjust the `cp` source path if the extension is installed somewhere else.

You can verify the permissions with:

```bash
sudo -l -U www-data
```

These permissions are intentionally limited to the commands required by the
extension. Do not grant the panel unrestricted access to Nginx or Certbot.

## Installation

1. From inside the extension directory:

```bash
zip -r ../proxy-manager.rext .
```

2. Copy `proxy-manager.rext` into your Reviactyl root directory.
3. Install the extension:

```bash
php artisan extension:install proxy-manager
```

4. Enable the extension:

```bash
php artisan extension:enable proxy-manager
```

## Backend routing

The Proxy Manager allows a public domain to be routed to a backend target such
as:

```text
backend.example.com:8080
```

For example:

```text
yourdomain.com → backend.example.com:8080
```

The Nginx configuration is generated automatically and deployed to the
appropriate Nginx configuration directories.

## Automatic deployment

When a proxy rule is deployed:

1. The Nginx configuration is generated in the extension's `data/generated`
   directory.
2. The generated configuration is copied to Nginx.
3. The configuration is enabled.
4. `nginx -t` validates the configuration.
5. Nginx is reloaded.
6. If SSL is enabled, Certbot automatically requests/configures the
   certificate.

Deployment output is stored per proxy rule and can be viewed from the
extension's log interface.

If deployment fails, the rule can be redeployed after the underlying issue has
been fixed.

## Default backend

The default infrastructure backend should point to:

```text
backend.example.com
```

The public panel/proxy-manager host should not need to expose or document an
internal infrastructure hostname such as `panel.yourdomain.com`.

## TCP/UDP

HTTP/HTTPS proxying is handled automatically through Nginx.

Raw TCP/UDP proxying requires Nginx's `stream` module and configuration at the
top-level Nginx configuration. The extension does not automatically modify
`nginx.conf`.

TCP/UDP configurations can therefore be generated separately and applied
manually where required.

## API

The frontend uses the following extension API base:

```ts
const API_BASE = '/api/client/extensions/proxy-manager/proxy-manager'
```

This value is defined in:

```text
frontend/src/proxy-manager-route.tsx
```

If the API returns 404 errors after installation, verify that the extension
route and frontend API base match.

## Security

The extension intentionally uses a restricted sudoers configuration instead
of granting the web panel unrestricted root access.

Do not add broad rules such as:

```text
(ALL) NOPASSWD: /usr/sbin/nginx
```

or unrestricted Certbot access unless you understand the security
implications.

